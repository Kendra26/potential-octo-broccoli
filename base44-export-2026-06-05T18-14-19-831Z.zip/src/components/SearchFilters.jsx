import { Tv, Search, X } from "lucide-react";

function FilterInput({ icon: Icon, placeholder, value, onChange, label, labelColor }) {
  return (
    <div className="relative">
      <Icon className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/50 pointer-events-none" />
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-11 pl-10 pr-9 rounded-xl bg-white border border-border text-sm placeholder:text-muted-foreground/50 outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 transition-all shadow-sm"
      />
      {label && (
        <span className={`absolute right-9 top-1/2 -translate-y-1/2 text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${labelColor}`}>
          {label}
        </span>
      )}
      {value && (
        <button onClick={() => onChange("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/50 hover:text-muted-foreground">
          <X className="h-3.5 w-3.5" />
        </button>
      )}
    </div>
  );
}

export default function SearchFilters({ showFilter, setShowFilter, andFilter, setAndFilter, orFilter, setOrFilter }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
      <FilterInput icon={Tv} placeholder="Show or movie name…" value={showFilter} onChange={setShowFilter} />
      <FilterInput
        icon={Search}
        placeholder="S03 WEB-DL  (ALL must match)"
        value={andFilter}
        onChange={setAndFilter}
        label="AND"
        labelColor="bg-blue-50 text-blue-600 border-blue-200"
      />
      <FilterInput
        icon={Search}
        placeholder="S04 1080p  (ANY must match)"
        value={orFilter}
        onChange={setOrFilter}
        label="OR"
        labelColor="bg-orange-50 text-primary border-primary/25"
      />
    </div>
  );
}