import { Zap } from "lucide-react";

export default function Header({ linkCount }) {
  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary to-orange-300 shadow-md shadow-primary/30 flex items-center justify-center">
          <Zap className="h-5 w-5 text-white fill-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-foreground tracking-tight leading-none">Magnet Vault</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{linkCount} link{linkCount !== 1 ? "s" : ""} in vault</p>
        </div>
      </div>
      <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-medium px-2.5 py-1 rounded-full">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
        live
      </div>
    </div>
  );
}