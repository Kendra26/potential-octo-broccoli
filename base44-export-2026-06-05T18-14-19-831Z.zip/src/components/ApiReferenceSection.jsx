import { useState } from "react";
import { Code, ChevronDown, Copy, CheckCircle2 } from "lucide-react";

const appOrigin = window.location.origin;

const endpoints = [
  {
    method: "POST",
    path: "/api/entities/MagnetLink",
    desc: "Add a single magnet link to the vault.",
    body: `{
  "magnet_url": "magnet:?xt=urn:btih:...",
  "show_name": "Breaking Bad",
  "episode_info": "S05E16",
  "quality": "1080p",
  "title": "Breaking Bad S05E16 1080p BluRay",
  "size": "2.3 GB",
  "source_url": "https://example-torrent-site.com/..."
}`,
    response: `{ "id": "abc123", "magnet_url": "magnet:?xt=...", ... }`,
  },
  {
    method: "GET",
    path: "/api/entities/MagnetLink",
    desc: "Retrieve all stored magnet links.",
    response: `[{ "id": "abc123", "magnet_url": "magnet:?xt=...", "show_name": "Breaking Bad", ... }]`,
  },
];

function CodeBlock({ text, copyKey }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div className="relative group">
      <pre className="bg-muted/50 border border-border/60 rounded-xl p-3 text-xs text-foreground/70 font-mono overflow-x-auto whitespace-pre-wrap leading-relaxed">{text}</pre>
      <button onClick={handleCopy}
        className="absolute top-2 right-2 p-1.5 rounded-lg bg-white border border-border opacity-0 group-hover:opacity-100 transition-all shadow-sm hover:border-primary/40">
        {copied ? <CheckCircle2 className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3 text-muted-foreground" />}
      </button>
    </div>
  );
}

export default function ApiReferenceSection() {
  const [open, setOpen] = useState(false);

  return (
    <div className="bg-white border border-border rounded-2xl overflow-hidden shadow-sm">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between px-5 py-4 text-sm font-semibold hover:bg-muted/40 transition-colors text-left"
      >
        <span className="flex items-center gap-2.5">
          <span className="w-7 h-7 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
            <Code className="h-3.5 w-3.5 text-primary" />
          </span>
          API Reference
        </span>
        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform duration-200 shrink-0 ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="px-5 pb-5 border-t border-border/60 space-y-5 pt-4">
          <p className="text-xs text-muted-foreground">
            Base URL: <code className="text-primary bg-primary/10 px-1.5 py-0.5 rounded font-mono border border-primary/20">{appOrigin}/api/entities/MagnetLink</code>
          </p>

          {endpoints.map((ep, i) => (
            <div key={i} className="space-y-2.5">
              <div className="flex items-center gap-2">
                <span className={`text-xs font-bold font-mono px-2.5 py-0.5 rounded-lg border ${ep.method === "POST" ? "bg-orange-50 text-primary border-primary/30" : "bg-emerald-50 text-emerald-700 border-emerald-200"}`}>
                  {ep.method}
                </span>
                <code className="text-xs text-foreground/70 font-mono">{ep.path}</code>
              </div>
              <p className="text-xs text-muted-foreground">{ep.desc}</p>
              {ep.body && (
                <div>
                  <p className="text-xs text-muted-foreground/60 mb-1.5 font-medium">Request body</p>
                  <CodeBlock text={ep.body} copyKey={`body-${i}`} />
                </div>
              )}
              <div>
                <p className="text-xs text-muted-foreground/60 mb-1.5 font-medium">Response</p>
                <CodeBlock text={ep.response} copyKey={`res-${i}`} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}