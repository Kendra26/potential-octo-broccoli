import { useState } from "react";
import { Copy, Trash2, ExternalLink, CheckCircle2, ChevronDown, ChevronUp } from "lucide-react";

export default function LinkCard({ link, onDelete }) {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(link.magnet_url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white border border-border rounded-xl shadow-sm p-4 space-y-2.5">
      {/* Top row: show name + badges */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-foreground text-sm leading-snug truncate">
            {link.show_name || link.title || <span className="text-muted-foreground/40 font-normal italic">Untitled</span>}
          </p>
          {link.title && link.title !== link.show_name && (
            <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug line-clamp-2">{link.title}</p>
          )}
          {link.size && <p className="text-xs text-muted-foreground/40 mt-0.5">{link.size}</p>}
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {link.episode_info && (