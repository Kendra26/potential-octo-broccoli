import { Database, Copy, Trash2, ExternalLink, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import LinkCard from "./LinkCard";

export default function ResultsPanel({ links, loading, onDelete }) {
  return (
    <div className="rounded-2xl border border-border bg-white shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-muted/30">
        <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Results</span>
        <span className="inline-flex items-center justify-center min-w-[26px] h-[22px] rounded-lg bg-primary/15 text-primary text-xs font-bold px-2 border border-primary/20">
          {links.length}
        </span>
      </div>

      {loading ? (
        <div className="py-20 flex flex-col items-center gap-3">
          <div className="w-7 h-7 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
          <p className="text-xs text-muted-foreground">Loading vault…</p>
        </div>
      ) : links.length === 0 ? (
        <div className="py-20 flex flex-col items-center gap-3 text-center px-6">
          <div className="w-16 h-16 rounded-2xl bg-muted border border-border flex items-center justify-center">
            <Database className="h-7 w-7 text-muted-foreground/40" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground/60">Vault is empty</p>
            <p className="text-xs text-muted-foreground/50 mt-1">Use the bookmarklet below to collect links from any torrent site</p>
          </div>
        </div>
      ) : (
        <>
          {/* Mobile: card list */}
          <div className="sm:hidden divide-y divide-border/40 p-3 space-y-2">
            {links.map((link) => (
              <LinkCard key={link.id} link={link} onDelete={onDelete} />
            ))}
          </div>

          {/* Desktop: table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-sm min-w-[800px]">
              <thead>
                <tr className="border-b border-border bg-muted/20">
                  <th className="text-left px-5 py-2.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap">Show / Title</th>
                  <th className="text-left px-4 py-2.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap w-28">Episode</th>
                  <th className="text-left px-4 py-2.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap w-24">Quality</th>
                  <th className="text-left px-4 py-2.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Full Magnet Link</th>
                  <th className="px-4 py-2.5 w-20"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/40">
                {links.map((link) => (
                  <LinkRow key={link.id} link={link} onDelete={onDelete} />
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

function LinkRow({ link, onDelete }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(link.magnet_url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <tr className="hover:bg-primary/3 transition-colors group align-top">
      <td className="px-5 py-3 min-w-[160px]">
        <p className="font-semibold text-foreground text-sm leading-snug">
          {link.show_name || <span className="text-muted-foreground/40 font-normal italic">Untitled</span>}
        </p>
        {link.title && (
          <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug">{link.title}</p>
        )}
        {link.size && <p className="text-xs text-muted-foreground/40 mt-0.5">{link.size}</p>}
      </td>
      <td className="px-4 py-3">
        {link.episode_info ? (
          <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-mono font-semibold border border-primary/20 whitespace-nowrap">
            {link.episode_info}
          </span>
        ) : <span className="text-muted-foreground/30 text-xs">—</span>}
      </td>
      <td className="px-4 py-3">
        {link.quality ? (
          <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-accent text-accent-foreground text-xs font-semibold border border-orange-200/60 whitespace-nowrap">
            {link.quality}
          </span>
        ) : <span className="text-muted-foreground/30 text-xs">—</span>}
      </td>
      <td className="px-4 py-3 max-w-xs xl:max-w-lg">
        <p className="text-xs font-mono text-muted-foreground/70 break-all leading-relaxed select-all">
          {link.magnet_url}
        </p>
      </td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity justify-end">
          {link.source_url && (
            <a href={link.source_url} target="_blank" rel="noopener noreferrer"
              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground/50 hover:text-foreground transition-colors" title="Source">
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          )}
          <button onClick={handleCopy}
            className="p-1.5 rounded-lg hover:bg-primary/10 text-muted-foreground/50 hover:text-primary transition-colors" title="Copy magnet link">
            {copied ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
          </button>
          <button onClick={() => onDelete(link.id)}
            className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground/50 hover:text-destructive transition-colors" title="Delete">
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </td>
    </tr>
  );
}