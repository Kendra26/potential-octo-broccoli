import { useState } from "react";
import { ChevronDown, Plus, X, ArrowUp, ArrowDown } from "lucide-react";

export default function DedupeConfig({ priorityKeywords, setPriorityKeywords }) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");

  const addKeyword = () => {
    const kw = input.trim().toUpperCase();
    if (!kw || priorityKeywords.includes(kw)) { setInput(""); return; }
    setPriorityKeywords([...priorityKeywords, kw]);
    setInput("");
  };

  const removeKeyword = (kw) => {
    setPriorityKeywords(priorityKeywords.filter((k) => k !== kw));
  };

  const moveKeyword = (index, dir) => {
    const next = [...priorityKeywords];
    const swap = index + dir;
    if (swap < 0 || swap >= next.length) return;
    [next[index], next[swap]] = [next[swap], next[index]];
    setPriorityKeywords(next);
  };

  return (
    <div className="bg-white border border-border rounded-2xl overflow-hidden shadow-sm">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center justify-between px-5 py-3.5 text-sm font-semibold hover:bg-muted/40 transition-colors text-left"
      >
        <span className="flex items-center gap-2.5">
          <span className="w-7 h-7 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 text-xs font-bold text-primary">
            ★
          </span>
          Dedupe Priority Keywords
          {priorityKeywords.length > 0 && (
            <span className="text-xs bg-primary/15 text-primary border border-primary/20 px-2 py-0.5 rounded-full font-bold">
              {priorityKeywords.length}
            </span>
          )}
        </span>
        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform duration-200 shrink-0 ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="px-5 pb-5 border-t border-border/60 space-y-3 pt-4">
          <p className="text-xs text-muted-foreground leading-relaxed">
            When deduping, the link matching the <strong>highest-ranked keyword</strong> (topmost) is kept. Use the arrows to change priority order.
          </p>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="e.g. REPACK, PROPER, REMUX…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") addKeyword(); }}
              className="flex-1 h-9 px-3 rounded-xl bg-white border border-border text-sm placeholder:text-muted-foreground/50 outline-none focus:border-primary focus:ring-2 focus:ring-primary/15 transition-all shadow-sm"
            />
            <button
              onClick={addKeyword}
              className="inline-flex items-center gap-1 px-3 h-9 rounded-xl bg-primary text-white text-xs font-bold shadow-sm hover:bg-primary/90 transition-all"
            >
              <Plus className="h-3.5 w-3.5" /> Add
            </button>
          </div>

          {priorityKeywords.length > 0 ? (
            <div className="space-y-1.5">
              {priorityKeywords.map((kw, i) => (
                <div key={kw} className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-orange-50 border border-primary/25">
                  <span className="text-xs text-primary/40 font-mono w-4 shrink-0 text-right">{i + 1}</span>
                  <span className="flex-1 text-xs font-semibold text-primary">{kw}</span>
                  <div className="flex items-center gap-0.5">
                    <button onClick={() => moveKeyword(i, -1)} disabled={i === 0} className="p-0.5 rounded hover:bg-primary/10 text-primary/50 hover:text-primary disabled:opacity-20 transition-colors">
                      <ArrowUp className="h-3 w-3" />
                    </button>
                    <button onClick={() => moveKeyword(i, 1)} disabled={i === priorityKeywords.length - 1} className="p-0.5 rounded hover:bg-primary/10 text-primary/50 hover:text-primary disabled:opacity-20 transition-colors">
                      <ArrowDown className="h-3 w-3" />
                    </button>
                    <button onClick={() => removeKeyword(kw)} className="p-0.5 rounded hover:bg-destructive/10 text-primary/50 hover:text-destructive transition-colors ml-1">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground/50 italic">No priority keywords set — dedupe keeps the first occurrence.</p>
          )}
        </div>
      )}
    </div>
  );
}