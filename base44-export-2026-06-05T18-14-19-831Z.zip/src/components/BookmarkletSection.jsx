import { useState } from "react";
import { Bookmark, ChevronDown, Zap, Info } from "lucide-react";

export default function BookmarkletSection() {
  const [open, setOpen] = useState(false);

  const appOrigin = window.location.origin;

  // This bookmarklet finds all magnet links on the page and saves each one
  // directly to the Base44 database via the public entities REST API
  const raw = `(function(){
var magnets=[].slice.call(document.querySelectorAll('a[href^="magnet:"]'));
if(!magnets.length){alert('No magnet links found on this page.');return;}
var showName=prompt('Show/movie name (optional):',document.title||'');
if(showName===null)return;
var items=magnets.map(function(a){
  var t=(a.textContent||'').trim()||a.title||'';
  var ep=(t.match(/S\\d{1,2}E\\d{1,2}/i)||[])[0]||'';
  var q=(t.match(/\\b(4K|2160p|1080p|720p|480p|x265|x264|HEVC|AVC|WEB-DL|BluRay)\\b/i)||[])[0]||'';
  var sz=(t.match(/\\d+(?:\\.\\d+)?\\s*(?:GB|MB)/i)||[])[0]||'';
  return{magnet_url:a.href,title:t,show_name:showName,episode_info:ep,quality:q,size:sz,source_url:location.href};
});
var saved=0;var failed=0;var total=items.length;
function done(){if(saved+failed===total){alert('Vault updated: '+saved+' link(s) saved'+(failed?' ('+failed+' failed)':'')+'. Refresh the page to see them.');}}
items.forEach(function(item){
  fetch('${appOrigin}/api/entities/MagnetLink',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(item)})
  .then(function(r){if(r.ok){saved++;}else{failed++;}done();})
  .catch(function(){failed++;done();});