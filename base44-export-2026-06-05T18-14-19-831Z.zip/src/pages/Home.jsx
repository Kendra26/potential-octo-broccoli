const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useMemo } from "react";

import Header from "@/components/Header";
import SearchFilters from "@/components/SearchFilters";
import ResultsPanel from "@/components/ResultsPanel";
import BookmarkletSection from "@/components/BookmarkletSection";
import ApiReferenceSection from "@/components/ApiReferenceSection";
import DedupeConfig from "@/components/DedupeConfig";
import { Copy, ArrowUpDown, Layers, RefreshCw, Trash2 } from "lucide-react";

// ── helpers ────────────────────────────────────────────────────────────────

/** Normalise a string: lowercase, replace dots/underscores/hyphens with spaces, collapse spaces */
function normalise(str) {
  return (str || "")
    .toLowerCase()
    .replace(/[._\-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Parse SxxExx from a string → { season: number, episode: number } or null */
function parseEpisode(str) {
  const m = (str || "").match(/S(\d{1,3})E(\d{1,3})/i);
  if (!m) return null;
  return { season: parseInt(m[1], 10), episode: parseInt(m[2], 10) };
}

/** Numeric episode sort key (season * 10000 + episode, or Infinity if none) */
function episodeSortKey(link) {
  const ep = parseEpisode(link.episode_info) || parseEpisode(link.title) || parseEpisode(link.magnet_url);
  if (!ep) return Infinity;
  return ep.season * 10000 + ep.episode;
}

/**
 * Deduplicate links by (show_name + episode_info).
 * Among duplicates, keep the one that contains a priority keyword (case-insensitive).
 * If none match a keyword, keep the first occurrence.
 */
function dedupeLinks(linkList, priorityKeywords) {
  const seen = new Map(); // key → best link so far

  for (const link of linkList) {
    const showKey = normalise(link.show_name || link.title || "");
    const epKey = normalise(link.episode_info || "");
    const dedupeKey = `${showKey}|||${epKey}`;

    if (!seen.has(dedupeKey)) {
      seen.set(dedupeKey, link);
    } else {
      // Compare priority rank — lower index = higher priority
      if (priorityKeywords.length > 0) {
        const rank = (l) => {
          const hay = [l.title, l.magnet_url, l.quality].filter(Boolean).join(" ").toUpperCase();
          const idx = priorityKeywords.findIndex((kw) => hay.includes(kw.toUpperCase()));
          return idx === -1 ? Infinity : idx;
        };
        if (rank(link) < rank(seen.get(dedupeKey))) {
          seen.set(dedupeKey, link);
        }
      }
      // else keep the existing one
    }
  }

  return Array.from(seen.values());
}

// ── component ──────────────────────────────────────────────────────────────

export default function Home() {
  const [links, setLinks] = useState([]);
  const [showFilter, setShowFilter] = useState("");
  const [andFilter, setAndFilter] = useState("");
  const [orFilter, setOrFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [priorityKeywords, setPriorityKeywords] = useState(["REPACK", "PROPER"]);

  const fetchLinks = async () => {
    setLoading(true);
    const data = await db.entities.MagnetLink.list("-created_date", 500);
    setLinks(data);
    setLoading(false);
  };

  useEffect(() => { fetchLinks(); }, []);

  // ── filtered links ────────────────────────────────────────────────────────
  const filteredLinks = useMemo(() => {
    return links.filter((l) => {
      // Show filter: match against show_name OR title, normalised (dots = spaces)
      if (showFilter) {
        const needle = normalise(showFilter);
        const hay = normalise((l.show_name || "") + " " + (l.title || ""));
        if (!hay.includes(needle)) return false;
      }

      const fullText = [l.episode_info, l.quality, l.title, l.show_name, l.magnet_url]
        .filter(Boolean).join(" ").toLowerCase();

      // AND filter: every word must appear
      if (andFilter) {
        const words = andFilter.trim().toLowerCase().split(/\s+/).filter(Boolean);
        if (!words.every((w) => fullText.includes(w))) return false;
      }

      // OR filter: at least one word must appear
      if (orFilter) {
        const words = orFilter.trim().toLowerCase().split(/\s+/).filter(Boolean);
        if (!words.some((w) => fullText.includes(w))) return false;
      }

      return true;
    });
  }, [links, showFilter, andFilter, orFilter]);

  // ── actions ───────────────────────────────────────────────────────────────

  const handleCopyAll = () => {
    navigator.clipboard.writeText(filteredLinks.map((l) => l.magnet_url).join("\n"));
  };

  const handleSortEpisode = () => {
    setLinks((prev) => [...prev].sort((a, b) => episodeSortKey(a) - episodeSortKey(b)));
  };

  const handleDedupe = async () => {
    // Work only on the currently filtered set
    const kept = new Set(dedupeLinks(filteredLinks, priorityKeywords).map((l) => l.id));
    const toDelete = filteredLinks.filter((l) => !kept.has(l.id));
    if (toDelete.length === 0) {
      alert("No duplicates found in the current filtered set.");
      return;
    }
    if (!window.confirm(`Remove ${toDelete.length} duplicate(s) from the vault?`)) return;
    await Promise.all(toDelete.map((l) => db.entities.MagnetLink.delete(l.id)));
    setLinks((prev) => prev.filter((l) => !toDelete.find((d) => d.id === l.id)));
  };

  const handlePurge = async () => {
    const scope = filteredLinks.length < links.length ? "filtered" : "all";
    const label = scope === "filtered"
      ? `Delete all ${filteredLinks.length} filtered link(s) from the vault?`
      : `Delete ALL ${links.length} links from the vault? This cannot be undone.`;
    if (!window.confirm(label)) return;
    await Promise.all(filteredLinks.map((l) => db.entities.MagnetLink.delete(l.id)));
    const deletedIds = new Set(filteredLinks.map((l) => l.id));
    setLinks((prev) => prev.filter((l) => !deletedIds.has(l.id)));
  };

  const handleDelete = async (id) => {
    await db.entities.MagnetLink.delete(id);
    setLinks((prev) => prev.filter((l) => l.id !== id));
  };

  const actions = [
    { icon: Copy, label: "Copy All", onClick: handleCopyAll, disabled: filteredLinks.length === 0 },
    { icon: ArrowUpDown, label: "Sort Ep ↑", onClick: handleSortEpisode },
    { icon: Layers, label: "Dedupe", onClick: handleDedupe, disabled: filteredLinks.length === 0 },
    { icon: RefreshCw, label: "Sync", onClick: fetchLinks },
    { icon: Trash2, label: "Purge", onClick: handlePurge, disabled: filteredLinks.length === 0, danger: true },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Subtle peach gradient blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-32 -left-32 w-[480px] h-[480px] rounded-full bg-primary/8 blur-[100px]" />
        <div className="absolute bottom-0 right-0 w-[360px] h-[360px] rounded-full bg-orange-200/30 blur-[80px]" />
      </div>

      <div className="relative max-w-5xl mx-auto px-4 pt-5 pb-12 space-y-4">
        <Header linkCount={links.length} />
        <SearchFilters
          showFilter={showFilter} setShowFilter={setShowFilter}
          andFilter={andFilter} setAndFilter={setAndFilter}
          orFilter={orFilter} setOrFilter={setOrFilter}
        />

        {/* Action bar */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-0.5">
          {actions.map(({ icon: Icon, label, onClick, disabled, danger }) => (
            <button
              key={label}
              onClick={onClick}
              disabled={disabled}
              className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-4 py-2 text-xs font-semibold border transition-all duration-150 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed shrink-0 shadow-sm ${
                danger
                  ? "bg-red-50 border-red-200 text-destructive hover:bg-red-100"
                  : "bg-white border-border text-foreground/70 hover:border-primary/50 hover:text-primary hover:bg-primary/5"
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {label}
            </button>
          ))}
        </div>

        <ResultsPanel links={filteredLinks} loading={loading} onDelete={handleDelete} />
        <DedupeConfig priorityKeywords={priorityKeywords} setPriorityKeywords={setPriorityKeywords} />
        <BookmarkletSection />
        <ApiReferenceSection />
      </div>
    </div>
  );
}